<?php
try {
  $pdo = new PDO(
    "mysql:host=sql300.infinityfree.com;dbname=if0_40156181_futebol;charset=utf8",
    "if0_40156181",
    "3lxGnvbpQ1rU3"
  );
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Erro: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Futebol Manager</title>

<style>
body {
    margin: 0;
    font-family: Arial;
    background: #0a0f1f;
    color: white;
}

header {
    background: #0f172a;
    padding: 18px;
    text-align: center;
    font-size: 22px;
    color: #38bdf8;
    font-weight: bold;
}

.container {
    width: 95%;
    margin: auto;
}

button {
    background: #2563eb;
    border: none;
    padding: 10px;
    color: white;
    border-radius: 8px;
    cursor: pointer;
    margin: 3px;
}

.filters {
    background: #111c33;
    padding: 15px;
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

select, input {
    padding: 8px;
    border-radius: 6px;
    border: none;
}

table {
    width: 100%;
    margin-top: 20px;
    border-collapse: collapse;
    background: #111c33;
}

th {
    background: #38bdf8;
    color: black;
    padding: 10px;
}

td {
    padding: 10px;
    border-bottom: 1px solid #1f2a44;
    text-align: center;
}

/* MODAL */
.modal {
    display: none;
    position: fixed;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
}

.modal-content {
    background: #111c33;
    width: 350px;
    margin: 10% auto;
    padding: 20px;
    border-radius: 10px;
}
</style>
</head>

<body>

<header>⚽ Futebol Manager</header>

<div class="container">

<!-- BOTÃO ADD -->
<button onclick="document.getElementById('add').style.display='block'">➕ Adicionar Jogador</button>

<form method="GET" class="filters">

<select name="clube">
<option value="">Clube</option>
<?php
$c = $pdo->query("SELECT DISTINCT NomeClube FROM jogador");
while ($r = $c->fetch()) {
echo "<option value='{$r['NomeClube']}'>{$r['NomeClube']}</option>";
}
?>
</select>

<select name="nacionalidade">
<option value="">Nacionalidade</option>
<?php
$p = $pdo->query("SELECT DISTINCT Pais FROM jogador");
while ($r = $p->fetch()) {
echo "<option value='{$r['Pais']}'>{$r['Pais']}</option>";
}
?>
</select>

<select name="posicao">
<option value="">Posição</option>
<?php
$pos = $pdo->query("SELECT DISTINCT Posicao FROM jogador");
while ($r = $pos->fetch()) {
echo "<option value='{$r['Posicao']}'>{$r['Posicao']}</option>";
}
?>
</select>

<input type="number" name="idade_min" placeholder="Idade min">
<input type="number" name="idade_max" placeholder="Idade max">

<button type="submit">Filtrar</button>
</form>

<!-- TABELA -->
<table>
<tr>
<th>Nº</th>
<th>Nome</th>
<th>Nacionalidade</th>
<th>Idade</th>
<th>Posição</th>
<th>Clube</th>
<th>Ações</th>
</tr>

<?php
$sql = "SELECT j.*, c.Pais AS PaisClube
        FROM jogador j
        LEFT JOIN clube c ON j.NomeClube = c.NomeClube
        WHERE 1=1";

$params = [];

if (!empty($_GET['clube'])) {
$sql .= " AND j.NomeClube=?";
$params[] = $_GET['clube'];
}

if (!empty($_GET['nacionalidade'])) {
$sql .= " AND j.Pais=?";
$params[] = $_GET['nacionalidade'];
}

if (!empty($_GET['posicao'])) {
$sql .= " AND j.Posicao=?";
$params[] = $_GET['posicao'];
}

if (!empty($_GET['idade_min'])) {
$sql .= " AND j.Idade>=?";
$params[] = $_GET['idade_min'];
}

if (!empty($_GET['idade_max'])) {
$sql .= " AND j.Idade<=?";
$params[] = $_GET['idade_max'];
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

while ($r = $stmt->fetch()) {
echo "<tr>
<td>{$r['NumAtleta']}</td>
<td>{$r['NomeJogador']}</td>
<td>{$r['Pais']}</td>
<td>{$r['Idade']}</td>
<td>{$r['Posicao']}</td>
<td>{$r['NomeClube']} ({$r['PaisClube']})</td>
<td>
<a href='?delete={$r['NumAtleta']}&clube={$r['NomeClube']}'>Apagar</a>
<button onclick=\"openEdit('{$r['NumAtleta']}','{$r['NomeJogador']}','{$r['Idade']}','{$r['Posicao']}','{$r['NomeClube']}')\">Editar</button>
</td>
</tr>";
}
?>
</table>

</div>

<!-- MODAL ADD -->
<div id="add" class="modal">
<div class="modal-content">
<h3>Adicionar Jogador</h3>
<form method="POST">
<input name="num" placeholder="Nº">
<input name="nome" placeholder="Nome">
<input name="pais" placeholder="Nacionalidade">
<input name="idade" placeholder="Idade">
<input name="posicao" placeholder="Posição">
<input name="clube" placeholder="Clube">
<button name="insert">Guardar</button>
</form>
<button onclick="document.getElementById('add').style.display='none'">Fechar</button>
</div>
</div>

<!-- MODAL EDIT -->
<div id="edit" class="modal">
<div class="modal-content">
<h3>Editar Jogador</h3>
<form method="POST">
<input type="hidden" name="id" id="eid">
<input name="nome" id="enome">
<input name="idade" id="eidade">
<input name="posicao" id="eposicao">
<input name="clube" id="eclube">
<button name="update">Atualizar</button>
</form>
<button onclick="document.getElementById('edit').style.display='none'">Fechar</button>
</div>
</div>

<?php
// INSERT
if (isset($_POST['insert'])) {
$pdo->prepare("INSERT INTO jogador VALUES (?,?,?,?,?,?)")
->execute([
$_POST['num'],
$_POST['nome'],
$_POST['pais'],
$_POST['idade'],
$_POST['posicao'],
$_POST['clube']
]);
header("Location: index.php");
}

// UPDATE
if (isset($_POST['update'])) {
$pdo->prepare("UPDATE jogador SET NomeJogador=?, Idade=?, Posicao=? WHERE NumAtleta=? AND NomeClube=?")
->execute([
$_POST['nome'],
$_POST['idade'],
$_POST['posicao'],
$_POST['id'],
$_POST['clube']
]);
header("Location: index.php");
}

// DELETE
if (isset($_GET['delete'])) {
$pdo->prepare("DELETE FROM jogador WHERE NumAtleta=? AND NomeClube=?")
->execute([$_GET['delete'], $_GET['clube']]);
header("Location: index.php");
}
?>

<script>
function openEdit(id,nome,idade,posicao,clube){
document.getElementById('edit').style.display='block';
document.getElementById('eid').value=id;
document.getElementById('enome').value=nome;
document.getElementById('eidade').value=idade;
document.getElementById('eposicao').value=posicao;
document.getElementById('eclube').value=clube;
}
</script>

</body>
</html>